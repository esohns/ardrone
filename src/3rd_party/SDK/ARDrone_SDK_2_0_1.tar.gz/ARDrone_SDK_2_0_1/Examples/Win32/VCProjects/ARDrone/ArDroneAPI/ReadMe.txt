========================================================================
    BIBLIOTH&Egrave;QUE STATIQUE&nbsp;: Vue d'ensemble du projet ArDroneAPI
========================================================================

AppWizard a cr&eacute;&eacute; ce projet de biblioth&egrave;que ArDroneAPI &agrave; votre intention.

Aucun fichier source n'a &eacute;t&eacute; cr&eacute;&eacute; dans le cadre de votre projet.


ArDroneAPI.vcproj
    Il s'agit du fichier projet principal pour les projets VC++ g&eacute;n&eacute;r&eacute;s &agrave; l'aide d'un Assistant Application.
    Il contient des informations relatives &agrave; la version de Visual&nbsp;C++ qui a g&eacute;n&eacute;r&eacute; le fichier,
    ainsi que des informations sur les plateformes, configurations et fonctionnalit&eacute;s du projet
    d'un Assistant Application.

/////////////////////////////////////////////////////////////////////////////
Autres remarques&nbsp;:

AppWizard utilise des commentaires "TODO:" pour indiquer les parties du code source o&ugrave; vous
devrez ajouter ou modifier du code.

/////////////////////////////////////////////////////////////////////////////
