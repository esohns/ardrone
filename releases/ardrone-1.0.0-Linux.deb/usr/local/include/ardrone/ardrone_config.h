/* config.h.in.cmake */

#define ARDRONE_VERSION_MAJOR 1
#define ARDRONE_VERSION_MINOR 0
#define ARDRONE_VERSION_MICRO 0
#define ARDRONE_VERSION_DEVEL devel

#define ARDRONE_PACKAGE "ardrone"

/* #undef VALGRIND_SUPPORT */

/* Name of package */
/* #undef  */
//#undef PACKAGE

/* Define to the address where bug reports for this package should be sent. */
//#undef PACKAGE_BUGREPORT

/* Define to the full name of this package. */
//#undef PACKAGE_NAME

/* Define to the full name and version of this package. */
//#undef PACKAGE_STRING

/* Define to the one symbol short name of this package. */
//#undef PACKAGE_TARNAME

/* Define to the home page for this package. */
//#undef PACKAGE_URL

/* Define to the version of this package. */
//#undef PACKAGE_VERSION

/* Version number of package */
//#undef VERSION

